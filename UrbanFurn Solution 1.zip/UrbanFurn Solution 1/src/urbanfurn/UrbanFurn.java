/*
* Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
* Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
*/
package urbanfurn;

/**
 *
 * @author MARTIN.R
 */
import java.util.*;
import java.io.*;

public class UrbanFurn {
    
    public static void main(String[] args) {
        
        //Declaring variables that hold user input
        int Shift = 0;
        int Hoursworked = 0;
        //Declaring variables used to process transactions and cakculations
        double Rate;
        double Regularpay;
        double Overtimepay = 0;
        double Overtimepayrate;
        double total = 0;
        double retirementdeduction = 0;
        double netpay = 0;
        String Retirement = "";
        
        //Creating an object of scanner to collect user input
        Scanner scanner = new Scanner(System.in);
        
        //I ask the user if their using stored data or new data
        System.out.println("Which data are you using? \n 1)New Data \n 2)Stored Data");
        int choice = Integer.parseInt(scanner.nextLine());
        
        //if the user is entering new data the program will ask the user to enter their
        //hours worked
        if (choice == 1) {
            
            //I use a try statement to ensure that the user enters hours as a number
            try {
                //Prompting the user to enter their hours worked
                System.out.println("Please enter you hours worked this week");
                Hoursworked = Integer.parseInt(scanner.nextLine());
                
            } catch (NumberFormatException e) {
                System.out.println("Invalid! Please enter a numeric value");
                //The program will reprompt the user to enter their hours if it's invalid
                Hoursworked = Integer.parseInt(scanner.nextLine());
            }
            
            //if the user selects stored data the program will read the hours stored in the textfile
        } else if (choice == 2) {
            try {
                //I create a new instance of random access file in read mode "r"
                
                RandomAccessFile file = new RandomAccessFile("Hours.txt", "r");
                
                //I declare a variable that reads lines from the text file
                String line;
                
                //The program will read each line in the file as long as they aren't empty
                while ((line = file.readLine()) != null) {
                    //I extract the line from the textfile until the semicolon at the end
                    //of each line to seperate them and store each of them in an array
                    String[] Hour = line.split(";");
                    //Then i assign the read hour to the hours worked variable while trimming
                    //any white space
                    Hoursworked = Integer.parseInt(Hour[0].trim());
                    
                }
            } catch (IOException e) {
                System.out.println("Error");
            }
        }
        //Prompting the user to select their shift number by entering the corresponding
        //shift number
        //I use another try catch that checks if the user enters a number
        try {
            
            System.out.println("Plese select your shift number (Enter the corresponding number) \n 1) First shift \n 2) Second Shift \n 3) Third Shift");
            Shift = Integer.parseInt(scanner.nextLine());
            
        } catch (NumberFormatException e) {
            System.out.println("Invalid! Please enter the number corresponding to your shift");
            Shift = Integer.parseInt(scanner.nextLine());
        }
        
        //I create a boolean that checks if the user selects a valid shift
        boolean validshift = true;
        
        //if the user enters a number greater than 3 and less than 1 then it'll be assigned
        //as invalid
        if (Shift > 3) {
            validshift = false;
        } else if (Shift < 1) {
            validshift = false;
        }
        
        //The program will reprompt the user to input their shift number again if it
        //isn't valid
        while (!validshift) {
            System.out.println("Invalid Shift selected, please enter the correct corresponding number");
            Shift = Integer.parseInt(scanner.nextLine());
        }
        
        //Setting hourly rates according to the employee shift
        if (Shift == 1) {
            Rate = 50;
            
        } else if (Shift == 2) {
            Rate = 70;
        } else {
            Rate = 90;
        }
        
        //Asking the second and third shift workers if they want to opt in for a retirement plan
        if (Shift > 1) {
            System.out.println("Would you like to opt in for a retirement plan? (Yes/no");
            Retirement = scanner.next();
        }
        
        //Displaying the users pay rate, hours worked and shift
        System.out.println("Hours Worked: " + Hoursworked + " Hours");
        System.out.println("Shift: " + Shift);
        System.out.println("Hourly pay Rate: R" + Rate);
        
        //Calculating employees regular pay
        Regularpay = Rate * Hoursworked;
        
        //Setting the total variable and regular pay
        total = Regularpay;
        
        //Setting the users Overtime if they work over 40 hours a week
        if (Hoursworked > 40) {
            
            //If the employee exceeds 40 hours their regular pay will be calculated
            //using 40 hours
            Regularpay = Rate * 40;
            
            //Then I determine how many extra hours the employee worked for
            int overhours = Hoursworked - 40;
            
            //Determining the new pay rate for overtime workers
            Overtimepayrate = Rate * 1.5;
            
            //Calculating overtime pay by implementing the new rate in the formula
            //and extra hours
            Overtimepay = overhours * Overtimepayrate;
            
            //Calculating the total gross pay of employees by overwritting the total
            //variable
            total = Regularpay + Overtimepay;
            
            //Equating the employees netpay to the total of their regular and overtime pay
            //if they work overtime
            netpay = total;
        }
        
        //Displaying the regular pay and overtime pay and total
        System.out.println("Regular Pay: R" + Regularpay);
        System.out.println("Overtime pay: R" + Overtimepay);
        System.out.println("Total: R" + total);
        
        //Checking if the user opted in for a retirement plan
        if (Retirement.equalsIgnoreCase("yes")) {
            
            //if the user is an overtime worker the retirement will be deducted from the total
            //of their regular pay and overtime
            retirementdeduction = total * 0.05;
            
            //The retirement deduction will be removed from the total of their regular and
            //overtime pay
            netpay = total - retirementdeduction;
            
            //Displaying the retirement deduction
            System.out.println("Retirement deduction: R" + retirementdeduction);
        }else{
            netpay = total;
        }
        
        System.out.println("Netpay R" + netpay);
        
        //Writing the data to a text file
        try {
            //I create a new instance of random access file called file in read-write mode
            //which means this method will read data then write it
            //"rw" means readwrite
            RandomAccessFile file = new RandomAccessFile("Hours.txt", "rw");
            
            //This moves the cursor in the text file to the end of the file
            //meaning we add new data after each other
            file.seek(file.length());
            
            //Using write bytes to add "hours worked" as single bytes in the text file
            //the label and data are both their own byte hence I use bytes insted of byte
            file.writeBytes(Hoursworked + ";\n");
            
            file.close();
            
            System.out.println("Your hours this week have been recorded");
        } catch (IOException e) {
            System.out.println("Error");
        }
    }
    
}
