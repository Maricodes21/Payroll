/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package urbanfurn;

import org.junit.Test;
import static org.junit.Assert.*;


/**
 *
 * @author MARTIN.R
 */
public class calculationtestsTest {
    
    public calculationtestsTest() {
    }

    @Test
    public void testRate1() {
        System.out.println("Checking if the assigned hourly rate for shift 1 is 50");
       int Shift = 1;
       double Rate = 0;
       calculationtests test = new calculationtests();
       int expresult = 50;
       double result = test.Rate(Shift, Rate);
       int delta = 0;
       assertEquals(expresult,result, delta);
    }
      @Test
    public void testRate2() {
        System.out.println("Checking if the assigned hourly rate for shift 2 is 70");
       int Shift = 2;
       double Rate = 0;
       calculationtests test = new calculationtests();
       int expresult = 70;
       double result = test.Rate(Shift, Rate);
       int delta = 0;
       assertEquals(expresult,result, delta);
    }
         @Test
    public void testRate3() {
        System.out.println("Checking if the assigned hourly rate for shift 3 is 90");
       int Shift = 3;
       double Rate = 0;
       calculationtests test = new calculationtests();
       int expresult = 90;
       double result = test.Rate(Shift, Rate);
       int delta = 0;
       assertEquals(expresult,result, delta);
    }
    @Test
      public void testregularpay() {
        System.out.println("Checking the users regular pay ");
       int Hours = 45;
       double Rate = 50;
       calculationtests test = new calculationtests();
       int expresult = 2250;
       double result = test.regularpay(Rate, Hours);
       int delta = 0;
       assertEquals(expresult,result, delta);
    }
      
       @Test
      public void testovertime() {
        System.out.println("Checking the users overtime pay ");
       int Hoursworked = 60;
       double Rate = 50;
       calculationtests test = new calculationtests();
       int expresult = 1500;
       double result = test.overtime(Rate, Hoursworked);
       int delta = 0;
       assertEquals(expresult,result, delta);
    }
   
   @Test
     public void testtotal() {
        System.out.println("Checking the users Total income ");
       double Regularpay  = 2250;
       double overtime = 1500;
       calculationtests test = new calculationtests();
       int expresult = 3750;
       double result = test.total(Regularpay, overtime);
       int delta = 0;
       assertEquals(expresult,result, delta);
    }    
    
     @Test
     public void testdeductions(){
        System.out.println("Checking how much will be deducted from the users' total");
       double total  = 3750;
       calculationtests test = new calculationtests();
       double expresult = 187.5;
       double result = test.retirement(total);
       int delta = 0;
       assertEquals(expresult,result, delta);
    } 
     
    @Test
     public void testnetpay(){
        System.out.println("checking if the users' netpay is calculated correctly ");
       double total  = 3750;
       double deductions = 187.5;
       calculationtests test = new calculationtests();
       double expresult = 3562.5;
       double result = test.netpay(total, deductions);
       int delta = 0;
       assertEquals(expresult,result, delta);
    }      
      
}
