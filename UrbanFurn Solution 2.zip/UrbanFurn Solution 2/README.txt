Description 
This is a payroll system for urban-Furn, this program calculates the pay for employees based on heir hours worked and determines their deductions if they opted in for retirement.

Features 
A user can select one of 3 shift types each shift has its hourly rate

It calculates regular pay and the users' overtime if they work more than 40 hours 

It offers an optional retirement plan for workers who work the second and third shift

The program can use new data or data that has been stored in a textfile 

How to use 
1. Run the program.
2. Choose whether to use new data or stored data.
3. If using new data, enter the hours worked this week.
4. Select your shift type by entering the corresponding number.
5. If you are a second or third-shift worker, you will be asked if you want to opt in for a retirement plan.
6. The program will then calculate and display your pay details.
7. Then the program will add your hours worked to the textfile.
