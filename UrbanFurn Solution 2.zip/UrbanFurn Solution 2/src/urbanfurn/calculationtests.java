/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package urbanfurn;

/**
 *
 * @author MARTIN.R
 */
public class calculationtests {
    
    public double Rate(int Shift, double Rate){
        if (Shift == 1){   
         Rate = 50;

        }else if(Shift == 2){
            Rate = 70;
        }else{
          Rate = 90;  
        }
      return Rate;  
    }
    public double regularpay(double Rate, int Hoursworked){
      double regularpay = Hoursworked * Rate;
      return regularpay;
    }
    
    public double overtime(double Rate, int Hoursworked){
        int extrahours = Hoursworked - 40;
        
        double extrapayrate = Rate * 1.5;
        
        double overtime = extrahours * extrapayrate;
        
        return overtime;
    }
    
    public double total(double regularpay, double overtime){
        
        double total = regularpay + overtime;
        
        return total;
    }
    public double retirement(double total){
        double deductions = total * 0.05;
        return deductions;
    }
    public double netpay(double total, double deductions){
        return total - deductions;
    }
}
